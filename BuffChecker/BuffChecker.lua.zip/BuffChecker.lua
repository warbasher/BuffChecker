-- Functions to make table setup easier.
local function tableIsAssoc(t)
	for _, v in pairs(t) do
		if (v == true) then return true end
		return false
	end
end

local function tableToAssoc(t)
	if not tableIsAssoc(t) then
		local t2 = {}
		for k, v in pairs(t) do
			t2[v] = true
		end

		return t2
	end

	return t
end

-- Settings for checking gear. Only checks in instances.
local nameToSlotID = {
	["Trinkets"] = {INVSLOT_TRINKET1, INVSLOT_TRINKET2},
}
local gearToRemove = {
	["Trinkets"] = tableToAssoc({"Riding Crop", "Carrot on a Stick", "Skybreaker Whip"}),
}

-- Settings for checking buffs.
local buffsToCheck = {
	["Mage"] = {
		["Mage/Molten armor"] = {
			SpellsToCheck = {"Mage Armor", "Molten Armor", "Ice Armor"},
			InstanceOnly = true,
			ShowButtons = true,
			RemindForBoss = true, -- Remind if there's only 8 minutes left and a boss is targeted.
		},
		["Arcane Intellect"] = {
			SpellsToCheck = {"Arcane Intellect", "Arcane Brilliance"},
			InstanceOnly = true,
			ShowButtons = true,
			RemindForBoss = true,
		}
	},

	["Druid"] = {
		["Thorns"] = {
			SpellsToCheck = {"Thorns"},
			InstanceOnly = false,
			ShowButtons = true,
		},
		["Mark of the wild"] = {
			SpellsToCheck = {"Mark of the Wild", "Gift of the Wild"},
			InstanceOnly = false,
			ShowButtons = true,
		},
		["Omen of clarity"] = {
			SpellsToCheck = {"Omen of Clarity"},
			InstanceOnly = false,
			ShowButtons = true,
		},
	},
}

local buttonCount = 0
local activeButtons = {}

local addonLoaded
local forcedLoadTime = 3

local tabToUse
local isInInstance
local delayInInstance = 10
local delayInOverworld = 30
local nextCheck = GetTime() + 5

-- For some reason druids return false on UnitIsDead("player")
-- They also have 1 health when in ghost form.
local function isDead()
	return (UnitHealth("player") <= 1)
end

-- Quick function to check if someone is 'mounted'
local isDruid, druidCheck
local function isMounted()
	if (not druidCheck) then
		druidCheck = true
		isDruid = (UnitClass("player") == "Druid")
	end

	if isDruid then
		if (AuraUtil.FindAuraByName("Flight Form", "player") or AuraUtil.FindAuraByName("Swift Flight Form", "player")) then return true end
	end

	return IsMounted("player")
end

local lastAfk
local lastMounted
local checkInWorld
local function variablesLoaded()
	local playerClass = UnitClass("player")
	for class, tab in pairs(buffsToCheck) do
		if (playerClass == class) then
			tabToUse = tab
			break
		end
	end

	for _, spellTab in pairs(tabToUse) do
		if (not spellTab.InstanceOnly) then
			checkInWorld = true
		end
	end

	lastAfk = UnitIsAFK("player")
	lastMounted = isMounted()

	nextCheck = 0
end

-- Combat check is already called in checkButtons().
local function ignoreNotifications()
	return (IsResting("player") or UnitIsAFK("player") or isMounted() or UnitOnTaxi("player") or isDead())
end

local function checkButtons()
	if (not addonLoaded) then return end
	if (buttonCount == 0) then return end
	if InCombatLockdown() then return end

	local toHide = {}
	for name, btnTab in pairs(activeButtons) do
		for _, btn in pairs(btnTab) do
			if btn:HasBuff() or ignoreNotifications() then
				table.insert(toHide, name)
				break
			end
		end
	end

	local indexRemoved
	local removedSomething = false
	for _, name in pairs(toHide) do
		for _, btn in pairs(activeButtons[name]) do
			-- Only shift if we didn't remove the very leftmost (max) element.
			if (btn.Index ~= (buttonCount - 1)) then
				indexRemoved = btn.Index
			end
			btn:Hide()
		end

		buttonCount = buttonCount - 1
		activeButtons[name] = nil
		removedSomething = true
	end

	-- Shift the other buttons over.
	if removedSomething and indexRemoved then
		for name, btnTab in pairs(activeButtons) do
			for index, btn in pairs(btnTab) do
				if (btn.Index ~= 0) then
					btn.Index = btn.Index - 1
				end
				local offset = (btn.Index * 35)
				btn:SetPoint("CENTER", offset, index * 35)
			end
		end
	end
end

local function shouldNotify(buffTab)
	if IsResting("player") or UnitIsAFK("player") then return end

	return (buffTab.InstanceOnly and isInInstance) and (not InCombatLockdown()) or (not buffTab.InstanceOnly)
end

local function getBuffDuration(buffName)
	for i=1, 40 do
		local name, _, _, _, _, expirationTime = UnitBuff("player", i)
		if (not name) then return -1 end

		if (name == buffName) then
			-- Return minutes left.
			return (-1 * (GetTime() - expirationTime) / 60)
		end
	end

	return -1
end

local function getLowBuffs()
	local lowBuffs = {}
	for name, buffTab in pairs(tabToUse) do
		local shouldCheck = shouldNotify(buffTab)
		if shouldCheck and (buffTab.RemindForBoss) then
			local toCheck = buffTab.SpellsToCheck
			local buffIsLow
			for _, buffName in pairs(toCheck) do
				local BuffExists = AuraUtil.FindAuraByName(buffName, "player")
				if BuffExists then
					local timeLeft = getBuffDuration(buffName)
					buffIsLow = (timeLeft > -1) and (timeLeft < 8)
					break
				end
			end

			if buffIsLow then
				table.insert(lowBuffs, name)
			end
		end
	end
	return lowBuffs
end

local function getMissingBuffs()
	local missingBuffs = {}
	for name, buffTab in pairs(tabToUse) do
		-- All because wow doesn't support 'continue' from lua, great job. Let's have 1000 tabs over.
		local shouldCheck = shouldNotify(buffTab)
		if shouldCheck then
			local toCheck = buffTab.SpellsToCheck
			local buffCount = #toCheck
			local missingBuffCount = 0
			for _, buffName in pairs(toCheck) do
				local BuffExists = AuraUtil.FindAuraByName(buffName, "player")
				if (not BuffExists) then
					missingBuffCount = missingBuffCount + 1
				end
			end

			local missingAllBuffs = (missingBuffCount == buffCount)
			if missingAllBuffs then
				table.insert(missingBuffs, name)
			end
		end
	end
	return missingBuffs
end

local function checkBuffs(override)
	if (not addonLoaded) then return end

	if (not override) and 
		((not tabToUse) or (nextCheck > GetTime())) then return end

	if ignoreNotifications() then return end

	local missingBuffs = getMissingBuffs()
	local numBuffsMissing = #missingBuffs
	if (numBuffsMissing > 0) then
		local toDisplay
		for i=1, numBuffsMissing do
			local name = missingBuffs[i]
			if (not toDisplay) then
				toDisplay = name
			elseif (i == numBuffsMissing) then
				if (numBuffsMissing == 2) then
					toDisplay = toDisplay.." and "..name
				else
					toDisplay = toDisplay..", and "..name
				end
			else
				toDisplay = toDisplay..", "..name
			end

			local buffTab = tabToUse[name]
			local toCheck = buffTab.SpellsToCheck
			if (not InCombatLockdown()) and buffTab.ShowButtons and (not activeButtons[name]) then
				local btnTab = {}
				for index, buffName in pairs(toCheck) do
					local alreadyExists = _G[buffName]
					local btn = _G[buffName] or CreateFrame("Button", buffName, nil, "SecureActionButtonTemplate");
					btn:RegisterForClicks("AnyUp")
					btn:SetAttribute("type", "spell")
					btn:SetAttribute("spell", buffName)
					btn:SetAttribute("unit", "player")

					local spellName, _, icon, _, _, _, spellID = GetSpellInfo(buffName)
					btn:SetPushedTexture(icon)
					btn:SetHighlightTexture(icon)
					btn:SetNormalTexture(icon)
					local offset = (buttonCount * 35)
					btn.Index = buttonCount
					btn:SetPoint("CENTER", offset, index * 35)
					btn:SetSize(35, 35)
					btn.DisplayedMessage = false
					btn.HasBuff = function(self)
						return AuraUtil.FindAuraByName(buffName, "player")
					end
					btn:SetScript("OnUpdate", function(self)
						local hasBuff = self:HasBuff()
						if (hasBuff or ignoreNotifications()) then
							if hasBuff and (not self.DisplayedMessage) then
								DEFAULT_CHAT_FRAME:AddMessage("|c00a400ffBuff Checker:|r |c0000ff00Applied "..buffName..".|r")
								self.DisplayedMessage = true
							end

							checkButtons()
						end
					end)
					btn:SetScript("OnEnter", function(self)
						GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
						GameTooltip:SetSpellByID(spellID)
						GameTooltip:Show()
					end)
					btn:SetScript("OnLeave",
						function(self) GameTooltip:Hide()
					end)
					btn:Show()

					table.insert(btnTab, btn)
				end

				buttonCount = buttonCount + 1
				activeButtons[name] = btnTab
			end
		end

		-- Current red: c00ff0000
		-- Light red color: c00ff6060
		DEFAULT_CHAT_FRAME:AddMessage("|c00a400ffBuff Checker:|r |c00ff0000You are missing "..toDisplay.."!|r")

		RaidNotice_AddMessage(RaidWarningFrame, "You are missing "..toDisplay.."!", ChatTypeInfo["RAID_WARNING"])
		PlaySound(8959)
		--PlaySoundFile(552503)

		if (not override) then
			local timerDelay = (isInInstance and delayInInstance) or delayInOverworld
			nextCheck = GetTime() + timerDelay
			C_Timer.After(timerDelay, checkBuffs)
		end

		return true
	end
end

local slotsToCheck = {}
for _, tab in pairs(nameToSlotID) do
	for _, slotID in pairs(tab) do
		slotsToCheck[slotID] = true
	end
end

local function checkGear(slotID)
	if (not isInInstance) then return end
	if slotID and (not slotsToCheck[slotID]) then return end

	local hasGearToRemove = false
	for slotName, items in pairs(gearToRemove) do
		local slotTab = nameToSlotID[slotName]
		for i=1, #slotTab do
			local slotID = slotTab[i]
			local link = GetInventoryItemLink("player", slotID)
			if link then
				local name = GetItemInfo(link) or ""
				if items[name] then
					DEFAULT_CHAT_FRAME:AddMessage("|c00a400ffBuff Checker:|r |c00ff0000You have "..name.." equipped!|r")
					RaidNotice_AddMessage(RaidWarningFrame, "You have "..name.." equipped!", ChatTypeInfo["RAID_WARNING"])
					hasGearToRemove = true
				end
			end
		end
	end

	if hasGearToRemove then
		local timerDelay = (isInInstance and delayInInstance) or delayInOverworld
		nextCheck = GetTime() + timerDelay
		C_Timer.After(timerDelay, checkGear)
	end
end

local function checkInstance()
	isInInstance = IsInInstance()
end

local function handleEvent(self, event, ...)
	local handlerMethod = self[event]
	if handlerMethod then
		handlerMethod(self, ...)
	end
end
local frame = CreateFrame("Frame", "EventsFrame")
frame:SetScript("OnEvent", handleEvent)

frame:RegisterEvent("ADDON_LOADED")
frame["ADDON_LOADED"] = function(self)
	variablesLoaded()
	self:UnregisterEvent("ADDON_LOADED")

	C_Timer.After(forcedLoadTime, function()
		addonLoaded = true
		self["PLAYER_ENTERING_WORLD"]()
	end)
end

frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame["PLAYER_ENTERING_WORLD"] = function(self)
	-- Slightly delay the check until we're in, if we check instantly we have nothing.
	C_Timer.After(2.5, function()
		checkInstance()
		-- These two will loop.
		checkBuffs()
		checkGear()
	end)
end

frame:RegisterEvent("PLAYER_REGEN_ENABLED")
frame["PLAYER_REGEN_ENABLED"] = function(self)
	checkButtons()
end

frame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
frame["PLAYER_EQUIPMENT_CHANGED"] = function(self, slotID)
	checkGear(slotID)
end

frame:RegisterEvent("UNIT_AURA")
frame["UNIT_AURA"] = function(self, unit)
	if (unit ~= "player") then return end
	local displayedMissingBuffs = checkBuffs()

	-- Check to see if we gained/lost mounted buff
	if (not checkInWorld) then return end

	-- Since flying is a buff, check for that.
	local curMounted = isMounted()
	if (curMounted == lastMounted) then return end
	lastMounted = curMounted

	-- Re-check buttons so we can disable them if we are flying.
	checkButtons()
	-- If we didn't just display a missing buff message, and we stopped flying, send a message.
	if (not displayedMissingBuffs) and (not curMounted) then
		checkBuffs(true)
	end
end

frame:RegisterEvent("PLAYER_UPDATE_RESTING")
frame["PLAYER_UPDATE_RESTING"] = function(self)
	if (not checkInWorld) then self:UnregisterEvent("PLAYER_UPDATE_RESTING") return end

	-- Re-check buttons so we can disable them once we become rested.
	checkButtons()
	-- Check buffs in case we just left a rested area.
	checkBuffs(true)
end

frame:RegisterEvent("PLAYER_FLAGS_CHANGED")
frame["PLAYER_FLAGS_CHANGED"] = function(self, unit)
	if (not checkInWorld) then self:UnregisterEvent("PLAYER_FLAGS_CHANGED") return end
	if (unit ~= "player") then return end

	-- Only check this if our afk status changes.
	local curAfk = UnitIsAFK("player")
	if (curAfk == lastAfk) then return end
	lastAfk = curAfk

	-- Re-check buttons so we can disable them if we are afk.
	checkButtons()
	checkBuffs(true)
end

-- Flight path checks.
frame:RegisterEvent("PLAYER_CONTROL_GAINED")
frame["PLAYER_CONTROL_GAINED"] = function(self)
	if (not checkInWorld) then self:UnregisterEvent("PLAYER_CONTROL_GAINED") return end
	checkButtons()
	checkBuffs(true)
end

frame:RegisterEvent("PLAYER_CONTROL_LOST")
frame["PLAYER_CONTROL_LOST"] = function(self)
	if (not checkInWorld) then self:UnregisterEvent("PLAYER_CONTROL_LOST") return end
	checkButtons()
	checkBuffs(true)
end

local hasBossTargeted
local function shouldDisplayLowBuffs()
	return hasBossTargeted and (not ignoreNotifications())
end
local nextLowBuffCheck = 0
local function checkForLowBuffs()
	if (not shouldDisplayLowBuffs()) then return end
	if (nextLowBuffCheck > GetTime()) then return end

	local missingBuffs = getLowBuffs()
	local numBuffsMissing = #missingBuffs
	if (numBuffsMissing > 0) then
		local toDisplay
		for i=1, numBuffsMissing do
			local name = missingBuffs[i]
			if (not toDisplay) then
				toDisplay = name
			elseif (i == numBuffsMissing) then
				if (numBuffsMissing == 2) then
					toDisplay = toDisplay.." and "..name
				else
					toDisplay = toDisplay..", and "..name
				end
			else
				toDisplay = toDisplay..", "..name
			end
		end

		DEFAULT_CHAT_FRAME:AddMessage("|c00a400ffBuff Checker:|r |c00ff0000The following buffs are low: "..toDisplay.."!|r")

		RaidNotice_AddMessage(RaidWarningFrame, "The following buffs are low: "..toDisplay.."!", ChatTypeInfo["RAID_WARNING"])
		PlaySound(8959)

		if (not override) then
			--local timerDelay = (isInInstance and delayInInstance) or delayInOverworld
			local timerDelay = 5
			nextLowBuffCheck = GetTime() + timerDelay
			C_Timer.After(timerDelay, checkForLowBuffs)
		end
	end
end

-- Should fire if ANYONE targets the boss.
local levelToCheck = -1
frame:RegisterEvent("UNIT_TARGET")
frame["UNIT_TARGET"] = function(self, unitID)
	if InCombatLockdown() then return end -- Don't bother.

	--hasBossTargeted = (UnitLevel("target") == -1)
	if (UnitLevel(unitID.."target") == levelToCheck) then
		hasBossTargeted = true
	end

	if hasBossTargeted then
		-- Now, search through and see if someone still has it targeted.
		local hasTarget
		for i=1, GetNumGroupMembers() do
			if (UnitLevel("raid"..i.."target") == levelToCheck) then
				hasTarget = true
				break
			end
		end

		hasBossTargeted = hasTarget
	end

	checkForLowBuffs()
end